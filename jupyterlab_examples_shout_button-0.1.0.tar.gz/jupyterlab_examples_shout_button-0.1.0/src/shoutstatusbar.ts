import { Widget } from '@lumino/widgets';

export class ShoutStatusBarSummary extends Widget {
  private _statusBarSummary: HTMLElement;

  constructor() {
    super();

    // Display the last shout time in the status bar
    this._statusBarSummary = document.createElement('p');
    this._statusBarSummary.classList.add('jp-shout-summary');
    this._statusBarSummary.innerText = 'Last Shout: (None)';
    this.node.appendChild(this._statusBarSummary);
  }

  /**
   * Set the widget text content
   *
   * @param summary The text to display
   */
  setSummary(summary: string) {
    this._statusBarSummary.innerText = summary;
  }
}
