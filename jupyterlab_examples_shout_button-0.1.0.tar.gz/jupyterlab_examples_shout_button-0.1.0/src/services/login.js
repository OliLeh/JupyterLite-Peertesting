import axios from 'axios'
const baseUrl = 'http://157.90.125.161:3500/users/login'

const login = async credentials => {
  const response = await axios.post(baseUrl, credentials)
  return response.data
}

export default { login }