import { config } from '../config';

import axios from 'axios'
import { ContentType } from 'yjs'
const baseUrl = `${config.BACKEND_URL}/testcases`

let token = null

const setToken = newToken => {
  token = `Bearer ${newToken}`
}

const create = async (pin_code, input, expected_output, description) => {
    const config = { headers: { Authorization: token } }
    const request = await axios.post(`${baseUrl}/${pin_code}`, { input, expected_output, description }, config)
    return request.data
  }

const getAll = async (pin_code) => {
    const config = { headers: { Authorization: token } }
    const request = await axios.get(`${baseUrl}/${pin_code}`, config)
    return request.data
}

const getMyTestcases = async (pin_code) => {
    const config = { headers: { Authorization: token } }
    const request = await axios.get(`${baseUrl}/${pin_code}/mytestcases/`, config)
    return request.data
}

const getAllPending = async (pin_code) => {
    const config = { headers: { Authorization: token } }
    const request = await axios.get(`${baseUrl}/${pin_code}/pendingtestcases/`, config)
    return request.data
}

const getMyPending = async (pin_code) => {
    const config = { headers: { Authorization: token } }
    const request = await axios.get(`${baseUrl}/${pin_code}/mypendingtestcases/`, config)
    return request.data
}


const approvePending = async (pin_code, testcase_id, modifiedTestcase) => {
    const config = { headers: { Authorization: token } }
    const request = await axios.put(`${baseUrl}/${pin_code}/approvependingtestcases/${testcase_id}`, { modifiedTestcase }, config)
    return request.data
}



export default { 
    setToken, create, getAll, getMyTestcases, getAllPending, getMyPending, approvePending
  }