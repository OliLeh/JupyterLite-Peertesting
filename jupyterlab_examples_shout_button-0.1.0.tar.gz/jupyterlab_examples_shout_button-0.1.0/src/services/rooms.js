import axios from 'axios'
import { ContentType } from 'yjs'
const baseUrl = 'http://157.90.125.161:3500/rooms'

let token = null

const setToken = newToken => {
  token = `Bearer ${newToken}`
}

const getAll = async () => {
  const config = { headers: { Authorization: token } }
  const request = await axios.get(baseUrl, config)
  return request.data
}


const getRoom = async (pin_code) => {
  const config = { headers: { Authorization: token } }
  const request = await axios.get(`${baseUrl}/${pin_code}`,config)
  return request.data
}

const create =  async newObject => {
  const config = { headers: { Authorization: token, 'Content-Type': 'multipart/form-data' } }
  const request = await axios.post(baseUrl, newObject, config)
  return request.data
}

const join = async (pin_code) => {
  const config = { headers: { Authorization: token } }
  const request = await axios.put(`${baseUrl}/${pin_code}`, {} , config)
  return request.data
}

const myrooms = async () => {
  const config = { headers: { Authorization: token } }
  const request = await axios.get(`${baseUrl}/myrooms`, config)
  return request.data
}

const getNotebook = async (pin_code) => {
  const config = { headers: { Authorization: token, 'Content-Type': 'application/octet-stream' }, responseType: 'blob' }
  const request = await axios.get(`${baseUrl}/${pin_code}/notebook`, config)
  return request
}

const deleteRoom = async (pin_code) => {
  const config = { headers: { Authorization: token } }
  const request = await axios.delete(`${baseUrl}/${pin_code}`, config)
  return request.data
}

// const update = async (id, newObject) => {
//   const request = await axios.put(`${baseUrl}/${id}`, newObject)
//   return request.data
// }

export default { 
  getAll, create, join, myrooms, setToken, getRoom, getNotebook, deleteRoom
}