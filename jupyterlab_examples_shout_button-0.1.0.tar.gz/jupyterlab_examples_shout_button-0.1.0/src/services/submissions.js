import axios from 'axios'
import { ContentType } from 'yjs'
const baseUrl = 'http://157.90.125.161:3500/submissions'

let token = null

const setToken = newToken => {
  token = `Bearer ${newToken}`
}

const submit = async (pin_code, func) => {
    const config = { headers: { Authorization: token } }
    const request = await axios.post(`${baseUrl}/${pin_code}`,{ func: func }, config)
    return request.data
  }

const getMySubmission = async (pin_code) => {
    const config = { headers: { Authorization: token } }
    const request = await axios.get(`${baseUrl}/${pin_code}/mysubmissions/`, config)
    return request.data
}
// update submit later
export default { setToken, submit, getMySubmission}

