import React from 'react';
import RoomService from './services/rooms';

interface NavbarProps {
  setActiveComponent: (message: string) => void;
  token: {token: string, username:string, id:string }|null;
  setToken: (token: { token: string, username: string, id: string } | null) => void;
  pin_code: string;
}

const Navbar: React.FC<NavbarProps> = ({ setActiveComponent, setToken, token , pin_code}) => {
  const [room, setRoom] = React.useState<any>(null);

  React.useEffect(() => {
    if (!token) {
      setActiveComponent('login');
    }
    else if (token.token) {
      initialRoom();
    }
  }, [pin_code])

  const initialRoom = async () => {
    try {
      const r = await RoomService.getRoom(pin_code);
      setRoom(r);
    } catch (exception) {
      alert(exception);
    }
  }

  const handleLogout = () => {
        window.localStorage.removeItem('loggedPuzzleappUser'); // Remove the session token from local storage
        setToken(null); // Set user to null
        setActiveComponent('login'); // Redirect to login page
  };

  const handleDeleteRoom = () => {
    if (window.confirm('Are you sure you want to delete the room?')) {
      RoomService.deleteRoom(pin_code);
      setActiveComponent('choose_room');
    }
  };
  return (
    <div className="room-navbar">
      <a onClick={() => setActiveComponent('room')}>Task</a>
      
      <div className="room-dropdown">
        <button className="room-dropbtn">Testcases ▼</button>
        <div className="room-dropdown-content">
        {token?.id === room?.instructor_id && (
            <a onClick={() => setActiveComponent('pending_testcases')}>Pending Testcases</a>
          )}
          <a onClick={() => setActiveComponent('all_testcases')}>All Testcases</a>
          <a onClick={() => setActiveComponent('create_testcases')}>Create Testcases</a>
          <a onClick={() => setActiveComponent('my_testcases')}>My Testcases</a>
        </div>
      </div>

      <div className="room-dropdown">
        <button className="room-dropbtn">Profile ▼</button>
        <div className="room-dropdown-content">
          <a onClick={() => setActiveComponent('update_profile')}>Update Profile</a>
          <a onClick={() => setActiveComponent('choose_room')}>Change Room</a>
          {token?.id === room?.instructor_id && (
            <a onClick={handleDeleteRoom}>Delete Room</a>
          )}
          <a onClick={handleLogout}>Logout</a>
        </div>
      </div>
    </div>
  );
};

export default Navbar;
