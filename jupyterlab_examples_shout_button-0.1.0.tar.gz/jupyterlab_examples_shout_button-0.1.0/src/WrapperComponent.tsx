import React from 'react';
import Navbar from './navbar';

interface WrapperComponentProps {
  setActiveComponent: (message: string) => void;
  setToken: (token: { token: string, username: string, id: string } | null) => void;
  token: { token: string, username: string, id: string } | null;
  pin_code: string;
  children: React.ReactNode;
}

const WrapperComponent: React.FC<WrapperComponentProps> = ({ setActiveComponent, setToken, token, pin_code, children }) => {
  return (
    <div className="login-wrapper">
      <div className="login-form">
        <Navbar setActiveComponent={setActiveComponent} setToken={setToken} token={token} pin_code={pin_code} />
        {children}
      </div>
    </div>
  );
}

export default WrapperComponent;
