import {
  JupyterFrontEnd,
  JupyterFrontEndPlugin
} from '@jupyterlab/application';

import { INotebookTracker /*, NotebookActions*/ } from '@jupyterlab/notebook';
import { IStatusBar } from '@jupyterlab/statusbar';
import { markdownIcon, fileUploadIcon } from '@jupyterlab/ui-components';

import { SideBarWrapperWidget } from './sidebarwrapper';
import { ShoutStatusBarSummary } from './shoutstatusbar';
import { IExecuteResult } from '@jupyterlab/nbformat';

// CODE BUTTONS
const CommandIds = {
  /**
   * Command to render a markdown cell.
   */
  renderMarkdownCell: 'toolbar-button:render-markdown-cell',
  /**
   * Command to run a code cell.
   */
  runCodeCell: 'toolbar-button:run-code-cell',

  executeAndPrint: 'toolbar-button:execute-and-print'
};

/**
 * JupyterLab extensions are made up of plugin(s). You can specify some
 * information about your plugin with the properties defined here. This
 * extension exports a single plugin, and lists the IStatusBar from
 * JupyterLab as optional.
 */
const plugin: JupyterFrontEndPlugin<void> = {
  id: '@jupyterlab-examples/shout-button:plugin',
  description:
    'An extension that adds a button and message to the right toolbar, with optional status bar widget in JupyterLab.',
  autoStart: true,

  requires: [INotebookTracker],
  // The IStatusBar is marked optional here. If it's available, it will
  // be provided to the plugin as an argument to the activate function
  // (shown below), and if not it will be null.
  optional: [IStatusBar],
  // Make sure to list any 'requires' and 'optional' features as arguments
  // to your activate function (activate is always passed an Application,
  // then required arguments, then optional arguments)

  // It is very important to put the notebookTracker after the app and not after the statusBar since somehow then it accesses the statusbar and not the notebook. 3h down the drain.
  activate: (
    app: JupyterFrontEnd,
    notebookTracker: INotebookTracker,
    statusBar: IStatusBar | null
  ) => {
    console.log('JupyterLab extension shout_button_message is activated!');

    // Create a ShoutWidget and add it to the interface in the right sidebar
    const sidebarWidget: SideBarWrapperWidget = new SideBarWrapperWidget(notebookTracker);
    sidebarWidget.id = 'JupyterSideBarWidget'; // Widgets need an id

    app.shell.add(sidebarWidget, 'right', { rank: 1 });

    // Check if the status bar is available, and if so, make
    // a status bar widget to hold some information
    if (statusBar) {
      const statusBarWidget = new ShoutStatusBarSummary();

      statusBar.registerStatusItem('shoutStatusBarSummary', {
        item: statusBarWidget
      });

      // Connect to the messageShouted to be notified when a new message
      // is published and react to it by updating the status bar widget.
      sidebarWidget.messageShouted.connect(
        (widget: SideBarWrapperWidget, { message }) => {
          statusBarWidget.setSummary(
            'Last Shout: ' + widget.lastShoutMessage?.toString() ?? '(None)'
          );
        }
      );
    }

    // HAS TO BE AFTER THE SIDEBAR WIDGET whyyyy?????
    /* Adds a command enabled only on code cell */
    app.commands.addCommand(CommandIds.runCodeCell, {
      icon: fileUploadIcon,
      caption: 'Print content to console',
      execute: () => {
        const activeCell = notebookTracker.activeCell;
        if (activeCell) {
          const cellContent = activeCell.model.toJSON().source;
          console.log('Cell content:', cellContent);
        } else {
          console.log('No active cell');
        }
        //app.commands.execute('notebook:run-cell');
      },
      isVisible: () => notebookTracker.activeCell?.model.type === 'code'
    });

    function isExecuteResult(output: any): output is IExecuteResult {
      return (
        output &&
        typeof output === 'object' &&
        'data' in output &&
        'text/plain' in output.data
      );
    }

    /* Adds a command enabled only on markdown cell */
    app.commands.addCommand(CommandIds.renderMarkdownCell, {
      icon: markdownIcon,
      caption: 'Print output to console',
      execute: async () => {
        const activeCell = notebookTracker.currentWidget;
        if (activeCell) {
          // This is code how we can execute a cell!
          //const sessionContext = activeCell.sessionContext;
          // Execute the active cell
          //await NotebookActions.run(
          //  notebookTracker.currentWidget!.content,
          //  sessionContext
          //);
          // Print the output of the cell to the console
          const cellOutput =
            activeCell.content.activeCell?.model.toJSON().outputs;
          if (Array.isArray(cellOutput)) {
            const firstOutput = cellOutput[0];
            if (isExecuteResult(firstOutput)) {
              const data = firstOutput.data['text/plain'];
              console.log('Data:', data);
            } else {
              console.log('No output');
            }
          }
        }
        //app.commands.execute('notebook:run-cell');
      },
      isVisible: () => notebookTracker.activeCell?.model.type === 'code'
    });

    app.commands.addCommand(CommandIds.executeAndPrint, {
      icon: markdownIcon,
      caption: 'Print output to console',
      execute: async () => {
        const activeCell = notebookTracker.currentWidget;
        if (activeCell) {
          // This is code how we can execute a cell!
          //const sessionContext = activeCell.sessionContext;
          // Execute the active cell
          //await NotebookActions.run(
          //  notebookTracker.currentWidget!.content,
          //  sessionContext
          //);
          // Print the output of the cell to the console
          const cellOutput =
            activeCell.content.activeCell?.model.toJSON().outputs;
          if (Array.isArray(cellOutput)) {
            const firstOutput = cellOutput[0];
            console.log('First output:', firstOutput);
            if (isExecuteResult(firstOutput)) {
              const data = firstOutput.data['image/png'];
              console.log(
                '<img src="data:image/png;base64,',
                data.toString(),
                '"/>'
              );
            } else {
              console.log('No output');
            }
          }
        }
        //app.commands.execute('notebook:run-cell');
      },
      isVisible: () => notebookTracker.activeCell?.model.type === 'code'
    });


  }
};

export default plugin;
