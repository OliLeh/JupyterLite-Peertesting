export const config = {
    BACKEND_URL: 'http://localhost:3500'
  };
  