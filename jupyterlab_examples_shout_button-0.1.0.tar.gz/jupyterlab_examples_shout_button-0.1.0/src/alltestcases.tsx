import React, { useState, useEffect } from 'react';
import SubissionService from './services/submissions';
import WrapperComponent from './WrapperComponent';
import TestcaseService from './services/testcases';

interface RoomProps {
  setActiveComponent: (message: string) => void;
  token: { token: string, username: string, id: string } | null;
  pin_code: string;
  setToken: (token: { token: string, username: string, id: string } | null) => void;
}

interface Testcase {
  id: string;
  room_id: string;
  user_id: string;
  room_name: string;
  input: string[];
  expected_output: string[];
  description: string;
}

interface SubmissionResult {
  test_case_id: Testcase;
  actual_output: string[];
  passed: Number;
}

interface Submission {
  _id: string;
  room_id: string;
  user_id: string;
  timestamp: Date;
  results: SubmissionResult[];
}

export const AllTestcases: React.FC<RoomProps> = ({ setActiveComponent, token, pin_code, setToken }) => {
  const [submission, setSubmission] = useState<Submission | null>(null);
  const [expandedTestcase, setExpandedTestcase] = useState<string | null>(null);

  // if not submission
  const [testcases, setTestcases] = useState<Testcase[]>([]);

  const initialTestcases = async () => {
    try {
      const s = await SubissionService.getMySubmission(pin_code)
      setSubmission(s);
      if (s === null) {
        const t = await TestcaseService.getAll(pin_code)
        setTestcases(t);
      }
    } catch (exception) {
      alert(exception);
    }
  }

  useEffect(() => {
    if (!token) {
      setActiveComponent('login');
    }
    else if (token.token) {
      initialTestcases();
    }
  }, [pin_code])

  const toggleVisibility = (testcaseId: string) => {
    setExpandedTestcase(expandedTestcase === testcaseId ? null : testcaseId);
  }

  interface TestCaseNoSubmissionProps {
    testcases: Testcase[] | [];
    expandedTestcase: string | null;
    toggleVisibility: (testcaseId: string) => void;
  }

  const TestCaseNoSubmission: React.FC<TestCaseNoSubmissionProps> = ({ testcases, expandedTestcase, toggleVisibility }) => {
    return(
      <div className="room-scrollbox">
      {testcases && testcases.map((testcase, index) => (
        <div key={index} className="testcase-container">
          <div className="testcase-header" onClick={() => toggleVisibility(testcase.id)}>
            <button className="toggle-button">
              {expandedTestcase === testcase.id ? '−' : '+'}
            </button>
            <h2 className="testcase-description">{testcase.description}</h2>
          </div>
          {expandedTestcase === testcase.id && (
            <div className="testcase-details">
              <div className="tile-grid">
                {testcase.input.map((input, iIndex) => (
                  <div key={iIndex} className="tile">
                    <img src={input} alt="" className="tile-img" />
                    <div>
                      <p className="tile-label">Expected: {testcase.expected_output[iIndex] || 'N/A'}</p>
                      <p className="tile-label">Predicted: -</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      ))}
    </div>
    )
  }

  interface TestCaseSubmissionProps {
    submission: Submission | null;
    expandedTestcase: string | null;
    toggleVisibility: (testcaseId: string) => void;
  }
  const TestCaseSubmission: React.FC<TestCaseSubmissionProps> = ({ submission, expandedTestcase, toggleVisibility }) => {
    return (
      <div className="room-scrollbox">
        {submission && submission.results.map((result, index) => (
          <div key={index} className="testcase-container">
            <div className="testcase-header" onClick={() => toggleVisibility(result.test_case_id.id)}>
              <button className="toggle-button">
                {expandedTestcase === result.test_case_id.id ? '−' : '+'}
              </button>
              <h2 className="testcase-description">{result.test_case_id.description}</h2>
              <p className="testcase-passed">{`(${result.passed}/${result.actual_output.length})`}</p>
            </div>
            {expandedTestcase === result.test_case_id.id && (
              <div className="testcase-details">
                <div className="tile-grid">
                  {result.test_case_id.input.map((input, iIndex) => (
                    <div key={iIndex} className={`tile ${result.test_case_id.expected_output[iIndex] === result.actual_output[iIndex] ? 'match' : 'mismatch'}`}>
                      <img src={input} alt="" className="tile-img" />
                      <div>
                        <p className="tile-label">Expected: {result.test_case_id.expected_output[iIndex] || 'N/A'}</p>
                        <p className="tile-label">Predicted: {result.actual_output[iIndex] || 'N/A'}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    );
  };

  return (
    <WrapperComponent setActiveComponent={setActiveComponent} setToken={setToken} token={token} pin_code={pin_code}>
      <div className="title">
        <h1>All Testcases</h1>
      </div>
      {submission ? (
        <TestCaseSubmission submission={submission} expandedTestcase={expandedTestcase} toggleVisibility={toggleVisibility} />
      ) : (
        <TestCaseNoSubmission testcases={testcases} expandedTestcase={expandedTestcase} toggleVisibility={toggleVisibility} />
      )}
    </WrapperComponent>
  );
}