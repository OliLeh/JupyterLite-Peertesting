import React, { useState, useRef } from 'react';
import { Stage, Layer, Line, Rect } from 'react-konva';

function Canvas({ handleUpload }) {
  const [tool, setTool] = useState('brush');
  const [lines, setLines] = useState([]);
  const [brushWidth, setBrushWidth] = useState(21);
  const isDrawing = useRef(false);
  const stageRef = useRef(null);
  const [label, setLabel] = useState('');

  const handleMouseDown = e => {
    isDrawing.current = true;
    const pos = e.target.getStage().getPointerPosition();
    setLines([...lines, { tool, points: [pos.x, pos.y], brushWidth }]);
  };

  const handleMouseMove = e => {
    if (!isDrawing.current) {
      return;
    }

    const stage = e.target.getStage();
    const point = stage.getPointerPosition();
    const lastLine = lines[lines.length - 1];
    lastLine.points = lastLine.points.concat([point.x, point.y]);

    lines.splice(lines.length - 1, 1, lastLine);
    setLines(lines.concat());
  };

  const handleMouseUp = () => {
    isDrawing.current = false;
  };

  const handleClear = () => {
    setLines([]);
  };

  const handleExport = () => {
    const uri = stageRef.current.toDataURL();
    console.log(uri);
    handleUpload(uri, label);
    handleClear();
    setLabel('');

    // we also can save uri as file
    // but in the demo on Konva website it will not work
    // because of iframe restrictions
    // but feel free to use it in your apps:
    // downloadURI(uri, 'stage.png');
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center'}}>
      <div style={{ display: 'flex', justifyContent: 'space-between', width:'250px' }}>
        <button onClick={handleClear}>Clear</button>

        <select
          value={tool}
          onChange={e => {
            setTool(e.target.value);
          }}
        >
          <option value="brush">Brush</option>
          <option value="eraser">Eraser</option>
        </select>
        <div>
          <input
            style={{ width: '70px' }}
            type="range"
            id="brushWidth"
            min="21"
            max="40"
            value={brushWidth}
            onChange={e => {
              setBrushWidth(parseInt(e.target.value, 10));
            }}
          />
        </div>
      </div>
      <div

      style={{ width: '250px', height: '250px', border: '1px solid black'}}
      >
      <Stage
        width={250}
        height={250}
        onMouseDown={handleMouseDown}
        onMousemove={handleMouseMove}
        onMouseup={handleMouseUp}
        onTouchstart={handleMouseDown}
        onTouchmove={handleMouseMove}
        onTouchend={handleMouseUp}
        ref={stageRef}
      >
        <Layer>
          <Rect width={250} height={250} fill="white" />
          {lines.map((line, i) => (
            <Line
              key={i}
              points={line.points}
              stroke="#000"
              strokeWidth={line.brushWidth}
              tension={0.5}
              lineCap="round"
              lineJoin="round"
              globalCompositeOperation={
                line.tool === 'eraser' ? 'destination-out' : 'source-over'
              }
            />
          ))}
        </Layer>
      </Stage>
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-around', width: '250px' }}>
        <label>Label<input style={{width:'20px'}} type="text" value={label} onChange={(e) => setLabel(e.target.value)}/></label>
        <button onClick={handleExport}>Add</button>
      </div>
    </div>
  );
}

export default Canvas;
