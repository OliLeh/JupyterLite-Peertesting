import React, {useState} from 'react';
import TestCaseService from './services/testcases'
import WrapperComponent from './WrapperComponent';
import RectangularDrawing from "./rectangulardrawing";


interface CreateTestcasesProps {
  setActiveComponent: (message: string) => void;
  token: {token: string, username:string, id:string }|null;
  pin_code: string;
  setToken: (token: { token: string, username: string, id: string } | null) => void;
}

export const CreateTestcases: React.FC<CreateTestcasesProps> = ({setActiveComponent, token, pin_code, setToken}) => {
    const [images, setImages] = useState<string[]>([]);
    const [labels, setLabels] = useState<string[]>([]);
    const [testcaseName, setTestcaseName] = useState<string>("");


  const handleUpload = (img: string, label: string) => {
    setImages([...images, img]);
    setLabels([...labels, label]);
  }

  const handleTestcaseNameChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setTestcaseName(event.target.value);
  };
  

    const remove = (index: number) => () => {
        setImages(images.filter((_, i) => i !== index));
        setLabels(labels.filter((_, i) => i !== index));
    }

    const handleSubmit = async () => {
        try {
            const response = await TestCaseService.create(pin_code, images, labels, testcaseName);
            setImages([]);
            setLabels([]);
            if (response.percentagePassed < 80){
              alert(`Testcases pending approval. ${response.percentagePassed.toFixed(2)}% passed reference solution.`);
            }
            else {
              alert(`Testcases created. ${response.percentagePassed.toFixed(2)}% passed reference solution.`);
            }
        } catch (exception) {
            alert(exception);
        }
    }

 
  return (
    <WrapperComponent setActiveComponent={setActiveComponent} setToken={setToken} token={token} pin_code={pin_code}>
      <div className="title">
        <h1>Create Testcases</h1>
      </div>

      <div><RectangularDrawing handleUpload={handleUpload} /></div>

      <div>
        <div>
          <h2 style={{textAlign: 'center'}}>Images</h2>
          {images.map((img, index) => (
            <div key={index} style={{display: 'flex', justifyContent: 'space-around', width: '250px'}}>
              <img src={img} alt="" width="20" height="20" />
              {labels[index]}
              <a onClick={remove(index)} style={{color: 'red'}}>✕</a>
            </div>
          ))}
        </div>
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', margin: '20px 0' }}>
          <input
            type="text"
            value={testcaseName}
            onChange={handleTestcaseNameChange}
            placeholder="Testcase Name"
            style={{ marginRight: '10px', padding: '5px', fontSize: '16px', width: '150px' }}
          />
          <button onClick={handleSubmit} style={{ padding: '5px 10px', fontSize: '16px' }}>Submit</button>
        </div>
      </div>
    </WrapperComponent>
  );
}
