import React from 'react';

interface ShoutListProps {
  shoutList: string[];
}

export const ShoutList = ({ shoutList }: ShoutListProps): JSX.Element => {
  return (
    <ul>
      {shoutList.map((shout, index) => (
        <li key={index}>{shout}</li>
      ))}
    </ul>
  );
};
