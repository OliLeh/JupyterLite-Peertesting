"use strict";
(self["webpackChunk_jupyterlab_examples_shout_button"] = self["webpackChunk_jupyterlab_examples_shout_button"] || []).push([["lib_index_js"],{

/***/ "./lib/InstructorUpload.js":
/*!*********************************!*\
  !*** ./lib/InstructorUpload.js ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./config */ "./lib/config.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! axios */ "webpack/sharing/consume/default/axios/axios");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);



function isExecuteResult(output) {
    return (output &&
        typeof output === 'object' &&
        'data' in output &&
        'text/plain' in output.data);
}
const InstructorUpload = ({ isVisible, notebooktracker, pin_code, token }) => {
    //const [predictions, setPredictions] = React.useState<string[]>([]);
    const upload = () => {
        var _a, _b;
        console.log('Uploading reference solution');
        const notebookTrack = notebooktracker;
        const notebookPanel = notebookTrack.currentWidget;
        if (notebookPanel) {
            const sessionContext = notebookPanel.sessionContext;
            let code = `
          import io
          import cloudpickle
          import base64
          
          file = io.BytesIO()
          cloudpickle.dump(predict,file)
          data_bytes = file.getvalue()
          function_data = base64.b64encode(data_bytes).decode('utf-8')
          function_data
          `;
            let future = (_b = (_a = sessionContext.session) === null || _a === void 0 ? void 0 : _a.kernel) === null || _b === void 0 ? void 0 : _b.requestExecute({
                code: code,
            });
            // get dump from kernel to js
            if (future) {
                future.onIOPub = (msg) => {
                    let content = msg.content;
                    if (isExecuteResult(content)) {
                        const func = content.data['text/plain'];
                        try {
                            console.log('Function length:', func.length);
                            const con = { headers: { Authorization: `Bearer ${token === null || token === void 0 ? void 0 : token.token}` } };
                            axios__WEBPACK_IMPORTED_MODULE_1___default().post(`${_config__WEBPACK_IMPORTED_MODULE_2__.config.BACKEND_URL}/rooms/${pin_code}/upload_sol`, { func: func }, con);
                        }
                        catch (e) {
                            console.log('Error:', e);
                        }
                    }
                };
            }
        }
    };
    /*const execute = () => {
        const con = { headers: { Authorization: `Bearer ${token?.token}` } };
        axios.get(`${config.BACKEND_URL}/rooms/${pin_code}/execute_sol`, con)
        .then(response => {
            setPredictions(response.data.predictions);
            })
            .catch(error => {
                console.error('Error getting solution:', error);
            });
    }*/
    if (!isVisible)
        return null;
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "login-button", onClick: upload }, "Upload Solution")
    /*
    <div className="login-input">
  
      <button className="login-button" onClick={upload}>Upload Solution</button>
      <button className="login-button" onClick={execute}>Execute Solution</button>
  
      <div>
      <h3>Predictions:</h3>
        {predictions.length > 0 ? (
          <ul>
            {predictions.map((prediction, index) => (
              <li key={index}>Image {index + 1}: {prediction}</li>
            ))}
          </ul>
        ) : (
          <p>No predictions yet.</p>
        )}
      </div>
    </div>*/
    );
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (InstructorUpload);


/***/ }),

/***/ "./lib/StudentUpload.js":
/*!******************************!*\
  !*** ./lib/StudentUpload.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./config */ "./lib/config.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! axios */ "webpack/sharing/consume/default/axios/axios");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);



function isExecuteResult(output) {
    return (output &&
        typeof output === 'object' &&
        'data' in output &&
        'text/plain' in output.data);
}
const StudentUpload = ({ isVisible, notebooktracker, pin_code, token }) => {
    const upload = () => {
        var _a, _b;
        const notebookTrack = notebooktracker;
        const notebookPanel = notebookTrack.currentWidget;
        if (notebookPanel) {
            const sessionContext = notebookPanel.sessionContext;
            let code = `
          import io
          import cloudpickle
          import base64
          
          file = io.BytesIO()
          cloudpickle.dump(predict,file)
          data_bytes = file.getvalue()
          function_data = base64.b64encode(data_bytes).decode('utf-8')
          function_data
          `;
            let future = (_b = (_a = sessionContext.session) === null || _a === void 0 ? void 0 : _a.kernel) === null || _b === void 0 ? void 0 : _b.requestExecute({
                code: code,
            });
            // get dump from kernel to js
            if (future) {
                future.onIOPub = (msg) => {
                    let content = msg.content;
                    if (isExecuteResult(content)) {
                        const func = content.data['text/plain'];
                        try {
                            console.log('Function length:', func.length);
                            const con = { headers: { Authorization: `Bearer ${token === null || token === void 0 ? void 0 : token.token}` } };
                            axios__WEBPACK_IMPORTED_MODULE_1___default().post(`${_config__WEBPACK_IMPORTED_MODULE_2__.config.BACKEND_URL}/submissions/${pin_code}`, { func: func }, con);
                        }
                        catch (e) {
                            console.log('Error:', e);
                        }
                    }
                };
            }
        }
    };
    if (!isVisible)
        return null;
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "login-button", onClick: upload }, "Submit Solution"));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (StudentUpload);


/***/ }),

/***/ "./lib/WrapperComponent.js":
/*!*********************************!*\
  !*** ./lib/WrapperComponent.js ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _navbar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./navbar */ "./lib/navbar.js");


const RoomWrapperComponent = ({ setActiveComponent, setToken, token, pin_code, children }) => {
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "login-wrapper" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_navbar__WEBPACK_IMPORTED_MODULE_1__["default"], { setActiveComponent: setActiveComponent, setToken: setToken, token: token, pin_code: pin_code }),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "login-form" }, children)));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RoomWrapperComponent);


/***/ }),

/***/ "./lib/alltestcases.js":
/*!*****************************!*\
  !*** ./lib/alltestcases.js ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AllTestcases: () => (/* binding */ AllTestcases)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _services_submissions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./services/submissions */ "./lib/services/submissions.js");
/* harmony import */ var _WrapperComponent__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./WrapperComponent */ "./lib/WrapperComponent.js");
/* harmony import */ var _services_testcases__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./services/testcases */ "./lib/services/testcases.js");




const AllTestcases = ({ setActiveComponent, token, pin_code, setToken }) => {
    const [submission, setSubmission] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [expandedTestcase, setExpandedTestcase] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [allTestcases, setAllTestcases] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [groupedTestcases, setGroupedTestcases] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [groupedSubmission, setGroupedSubmission] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [displayMode, setDisplayMode] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('normal');
    const hasUnrunTestcases = () => {
        return allTestcases.some(testcase => !(submission === null || submission === void 0 ? void 0 : submission.results.some(result => result.test_case_id.id === testcase.id)));
    };
    const groupTestcasesByOutput = (t, s) => {
        const groupedTestcases = {};
        const groupedSubmission = {};
        t.forEach(testcase => {
            let sub = s === null || s === void 0 ? void 0 : s.results.find(r => r.test_case_id.id === testcase.id);
            testcase.expected_output.forEach((output, i) => {
                if (!groupedTestcases[output]) {
                    groupedTestcases[output] = { id: output, room_id: testcase.room_id, user_id: testcase.user_id, room_name: testcase.room_name, input: [], expected_output: [], description: output };
                    groupedSubmission[output] = { test_case_id: groupedTestcases[output], actual_output: [], passed: 0 };
                }
                groupedTestcases[output].input.push(testcase.input[i]);
                groupedTestcases[output].expected_output.push(output);
                groupedSubmission[output].actual_output.push((sub === null || sub === void 0 ? void 0 : sub.actual_output[i]) || '');
                if ((sub === null || sub === void 0 ? void 0 : sub.actual_output[i]) === output) {
                    groupedSubmission[output].passed++;
                }
            });
        });
        setGroupedTestcases(Object.values(groupedTestcases));
        setGroupedSubmission({ _id: 'grouped', room_id: pin_code, user_id: (token === null || token === void 0 ? void 0 : token.id) || '', timestamp: new Date(), results: Object.values(groupedSubmission) });
    };
    const initialTestcases = async () => {
        try {
            const s = await _services_submissions__WEBPACK_IMPORTED_MODULE_1__["default"].getMySubmission(pin_code);
            setSubmission(s);
            const t = await _services_testcases__WEBPACK_IMPORTED_MODULE_2__["default"].getAll(pin_code);
            setAllTestcases(t);
            groupTestcasesByOutput(t, s);
        }
        catch (exception) {
            alert(exception);
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (!token) {
            setActiveComponent('login');
        }
        else if (token.token) {
            initialTestcases();
        }
    }, [pin_code]);
    const toggleVisibility = (testcaseId) => {
        setExpandedTestcase(expandedTestcase === testcaseId ? null : testcaseId);
    };
    const TestCaseItem = ({ testcase, result }) => {
        return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "testcase-container" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "testcase-header", onClick: () => toggleVisibility(testcase.id) },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "toggle-button" }, expandedTestcase === testcase.id ? '−' : '+'),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h2", { className: "testcase-description", style: { margin: "0", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" } }, testcase.description),
                result ? react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: "testcase-passed" }, `(${result.passed}/${result.actual_output.length})`) : react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: "testcase-passed" }, `(?/${testcase.expected_output.length})`)),
            expandedTestcase === testcase.id && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "testcase-details" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "tile-grid" }, testcase.input.map((input, iIndex) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { key: iIndex, className: (result && result.actual_output[iIndex]) ? (testcase.expected_output[iIndex] === result.actual_output[iIndex] ? 'tile match' : 'tile mismatch') : 'tile' },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("img", { src: input, alt: "", className: "tile-img" }),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: "tile-label" },
                            "Expected: ",
                            testcase.expected_output[iIndex] || 'N/A'),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: "tile-label" },
                            "Predicted: ",
                            result ? (result.actual_output[iIndex] || '-') : '-'))))))))));
    };
    const update = async () => {
        await _services_submissions__WEBPACK_IMPORTED_MODULE_1__["default"].updateSubmission(pin_code);
        const s = await _services_submissions__WEBPACK_IMPORTED_MODULE_1__["default"].getMySubmission(pin_code);
        setSubmission(s);
        groupTestcasesByOutput(allTestcases, s);
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_WrapperComponent__WEBPACK_IMPORTED_MODULE_3__["default"], { setActiveComponent: setActiveComponent, setToken: setToken, token: token, pin_code: pin_code },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "title" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h1", null, "All Testcases")),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "new-room-button", onClick: () => setDisplayMode(displayMode === 'normal' ? 'grouped' : 'normal') }, displayMode === 'normal' ? 'Group by Output' : 'Normal View'),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "room-scrollbox" }, displayMode === 'normal'
            ? allTestcases.map((testcase) => {
                const result = submission === null || submission === void 0 ? void 0 : submission.results.find(r => r.test_case_id.id === testcase.id);
                return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(TestCaseItem, { key: testcase.id, testcase: testcase, result: result });
            })
            : groupedTestcases.map((testcase) => {
                const result = groupedSubmission === null || groupedSubmission === void 0 ? void 0 : groupedSubmission.results.find(r => r.test_case_id.id === testcase.id);
                return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(TestCaseItem, { key: testcase.id, testcase: testcase, result: result });
            })),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { display: 'flex', flexDirection: 'column' }, title: hasUnrunTestcases() ? "" : "All testcases have been run" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "login-button", disabled: !hasUnrunTestcases(), onClick: update }, "Rerun submission"))));
};


/***/ }),

/***/ "./lib/autosizeinput.js":
/*!******************************!*\
  !*** ./lib/autosizeinput.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const AutosizeInput = ({ value, onChange }) => {
    const inputRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (inputRef.current) {
            inputRef.current.style.width = `${value.length}ch`;
        }
    }, [value]);
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { ref: inputRef, className: "inline-input", value: value, onChange: onChange }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AutosizeInput);


/***/ }),

/***/ "./lib/chooseroom.js":
/*!***************************!*\
  !*** ./lib/chooseroom.js ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ChooseRoom: () => (/* binding */ ChooseRoom)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _services_rooms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./services/rooms */ "./lib/services/rooms.js");
/* harmony import */ var _WrapperComponent__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./WrapperComponent */ "./lib/WrapperComponent.js");



const RoomList = react__WEBPACK_IMPORTED_MODULE_0___default().memo(({ rooms, setRoomPin, setActiveComponent }) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { height: '150px', overflowY: 'scroll', marginTop: "1.5rem", marginBottom: "1.5rem", border: '2px solid rgb(204, 204, 204)', borderRadius: '8px' } }, rooms.map(room => react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { key: room.id },
    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: 'room-button', onClick: () => { setRoomPin(room.pin_code); setActiveComponent('room'); } },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { display: 'flex', flexDirection: 'row', justifyContent: 'space-between' } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { style: { margin: 0, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' } }, room.room_name),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { style: { margin: 0 } }, room.pin_code))))))));
const ChooseRoom = ({ setActiveComponent, token, setRoomPin, setToken }) => {
    const [temproompin, setTempRoomPin] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [rooms, setRooms] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const handleChange = (event) => {
        const newValue = event.target.value;
        if (/^[0-9]+$/.test(newValue) && newValue.length <= 6 || newValue === '') {
            setTempRoomPin(newValue);
        }
    };
    const initialRoom = async () => {
        try {
            await _services_rooms__WEBPACK_IMPORTED_MODULE_1__["default"].setToken(token === null || token === void 0 ? void 0 : token.token);
            const r = await _services_rooms__WEBPACK_IMPORTED_MODULE_1__["default"].myrooms();
            setRooms(r);
        }
        catch (exception) {
            if (exception.response.status === 401) {
                setActiveComponent('login');
            }
            else {
                alert(exception);
            }
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (!token) {
            setActiveComponent('login');
        }
        else if (token.token) {
            initialRoom();
        }
    }, []);
    const joinRoom = async (event) => {
        event.preventDefault();
        if (temproompin.length !== 6) {
            alert('Please enter a 6 digit room PIN');
        }
        else {
            setRoomPin(temproompin);
            setActiveComponent('room');
        }
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_WrapperComponent__WEBPACK_IMPORTED_MODULE_2__["default"], { setActiveComponent: setActiveComponent, token: token, setToken: setToken },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("form", { className: "login-form2", onSubmit: joinRoom },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { className: "login-input", type: "text", placeholder: "Room PIN", value: temproompin, onChange: handleChange, required: true }),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "login-button", type: "submit" }, "Join"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(RoomList, { rooms: rooms, setRoomPin: setRoomPin, setActiveComponent: setActiveComponent }),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "new-room-button", onClick: () => setActiveComponent('newroom') }, "Create New Room"))));
};


/***/ }),

/***/ "./lib/config.js":
/*!***********************!*\
  !*** ./lib/config.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   config: () => (/* binding */ config)
/* harmony export */ });
const config = {
    BACKEND_URL: 'http://localhost:3500'
};


/***/ }),

/***/ "./lib/createtestcases.js":
/*!********************************!*\
  !*** ./lib/createtestcases.js ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CreateTestcases: () => (/* binding */ CreateTestcases)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _services_testcases__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./services/testcases */ "./lib/services/testcases.js");
/* harmony import */ var _WrapperComponent__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./WrapperComponent */ "./lib/WrapperComponent.js");
/* harmony import */ var _rectangulardrawing__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./rectangulardrawing */ "./lib/rectangulardrawing.js");




const CreateTestcases = ({ setActiveComponent, token, pin_code, setToken }) => {
    const [images, setImages] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [labels, setLabels] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [testcaseName, setTestcaseName] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
    const handleUpload = (img, label) => {
        setImages([...images, img]);
        setLabels([...labels, label]);
    };
    const handleTestcaseNameChange = (event) => {
        setTestcaseName(event.target.value);
    };
    const remove = (index) => () => {
        setImages(images.filter((_, i) => i !== index));
        setLabels(labels.filter((_, i) => i !== index));
    };
    const handleSubmit = async () => {
        try {
            const response = await _services_testcases__WEBPACK_IMPORTED_MODULE_1__["default"].create(pin_code, images, labels, testcaseName);
            setImages([]);
            setLabels([]);
            if (response.percentagePassed < 80) {
                alert(`Testcases pending approval. ${response.percentagePassed.toFixed(2)}% passed reference solution.`);
            }
            else {
                alert(`Testcases created. ${response.percentagePassed.toFixed(2)}% passed reference solution.`);
            }
        }
        catch (exception) {
            alert(exception);
        }
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_WrapperComponent__WEBPACK_IMPORTED_MODULE_2__["default"], { setActiveComponent: setActiveComponent, setToken: setToken, token: token, pin_code: pin_code },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "title" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h1", null, "Create Testcases")),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rectangulardrawing__WEBPACK_IMPORTED_MODULE_3__["default"], { handleUpload: handleUpload })),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h2", { style: { textAlign: 'center' } }, "Images"),
                images.map((img, index) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { key: index, style: { display: 'flex', justifyContent: 'space-around', width: '250px' } },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("img", { src: img, alt: "", width: "20", height: "20" }),
                    labels[index],
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("a", { onClick: remove(index), style: { color: 'red' } }, "\u2715"))))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { display: 'flex', justifyContent: 'center', alignItems: 'center', margin: '20px 0' } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: "text", value: testcaseName, onChange: handleTestcaseNameChange, placeholder: "Testcase Name", style: { marginRight: '10px', padding: '5px', fontSize: '16px', width: '150px' } }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { onClick: handleSubmit, style: { padding: '5px 10px', fontSize: '16px' } }, "Submit")))));
};


/***/ }),

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_statusbar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/statusbar */ "webpack/sharing/consume/default/@jupyterlab/statusbar");
/* harmony import */ var _jupyterlab_statusbar__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_statusbar__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _sidebarwrapper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./sidebarwrapper */ "./lib/sidebarwrapper.js");
/* harmony import */ var _shoutstatusbar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./shoutstatusbar */ "./lib/shoutstatusbar.js");





// CODE BUTTONS
const CommandIds = {
    /**
     * Command to render a markdown cell.
     */
    renderMarkdownCell: 'toolbar-button:render-markdown-cell',
    /**
     * Command to run a code cell.
     */
    runCodeCell: 'toolbar-button:run-code-cell',
    executeAndPrint: 'toolbar-button:execute-and-print'
};
/**
 * JupyterLab extensions are made up of plugin(s). You can specify some
 * information about your plugin with the properties defined here. This
 * extension exports a single plugin, and lists the IStatusBar from
 * JupyterLab as optional.
 */
const plugin = {
    id: '@jupyterlab-examples/shout-button:plugin',
    description: 'An extension that adds a button and message to the right toolbar, with optional status bar widget in JupyterLab.',
    autoStart: true,
    requires: [_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__.INotebookTracker],
    // The IStatusBar is marked optional here. If it's available, it will
    // be provided to the plugin as an argument to the activate function
    // (shown below), and if not it will be null.
    optional: [_jupyterlab_statusbar__WEBPACK_IMPORTED_MODULE_1__.IStatusBar],
    // Make sure to list any 'requires' and 'optional' features as arguments
    // to your activate function (activate is always passed an Application,
    // then required arguments, then optional arguments)
    // It is very important to put the notebookTracker after the app and not after the statusBar since somehow then it accesses the statusbar and not the notebook. 3h down the drain.
    activate: (app, notebookTracker, statusBar) => {
        console.log('JupyterLab extension shout_button_message is activated!');
        // Create a ShoutWidget and add it to the interface in the right sidebar
        const sidebarWidget = new _sidebarwrapper__WEBPACK_IMPORTED_MODULE_3__.SideBarWrapperWidget(notebookTracker);
        sidebarWidget.id = 'JupyterSideBarWidget'; // Widgets need an id
        app.shell.add(sidebarWidget, 'right', { rank: 1 });
        // Check if the status bar is available, and if so, make
        // a status bar widget to hold some information
        if (statusBar) {
            const statusBarWidget = new _shoutstatusbar__WEBPACK_IMPORTED_MODULE_4__.ShoutStatusBarSummary();
            statusBar.registerStatusItem('shoutStatusBarSummary', {
                item: statusBarWidget
            });
            // Connect to the messageShouted to be notified when a new message
            // is published and react to it by updating the status bar widget.
            sidebarWidget.messageShouted.connect((widget, { message }) => {
                var _a, _b;
                statusBarWidget.setSummary((_b = 'Last Shout: ' + ((_a = widget.lastShoutMessage) === null || _a === void 0 ? void 0 : _a.toString())) !== null && _b !== void 0 ? _b : '(None)');
            });
        }
        // HAS TO BE AFTER THE SIDEBAR WIDGET whyyyy?????
        /* Adds a command enabled only on code cell */
        app.commands.addCommand(CommandIds.runCodeCell, {
            icon: _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.fileUploadIcon,
            caption: 'Print content to console',
            execute: () => {
                const activeCell = notebookTracker.activeCell;
                if (activeCell) {
                    const cellContent = activeCell.model.toJSON().source;
                    console.log('Cell content:', cellContent);
                }
                else {
                    console.log('No active cell');
                }
                //app.commands.execute('notebook:run-cell');
            },
            isVisible: () => { var _a; return ((_a = notebookTracker.activeCell) === null || _a === void 0 ? void 0 : _a.model.type) === 'code'; }
        });
        function isExecuteResult(output) {
            return (output &&
                typeof output === 'object' &&
                'data' in output &&
                'text/plain' in output.data);
        }
        /* Adds a command enabled only on markdown cell */
        app.commands.addCommand(CommandIds.renderMarkdownCell, {
            icon: _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.markdownIcon,
            caption: 'Print output to console',
            execute: async () => {
                var _a;
                const activeCell = notebookTracker.currentWidget;
                if (activeCell) {
                    // This is code how we can execute a cell!
                    //const sessionContext = activeCell.sessionContext;
                    // Execute the active cell
                    //await NotebookActions.run(
                    //  notebookTracker.currentWidget!.content,
                    //  sessionContext
                    //);
                    // Print the output of the cell to the console
                    const cellOutput = (_a = activeCell.content.activeCell) === null || _a === void 0 ? void 0 : _a.model.toJSON().outputs;
                    if (Array.isArray(cellOutput)) {
                        const firstOutput = cellOutput[0];
                        if (isExecuteResult(firstOutput)) {
                            const data = firstOutput.data['text/plain'];
                            console.log('Data:', data);
                        }
                        else {
                            console.log('No output');
                        }
                    }
                }
                //app.commands.execute('notebook:run-cell');
            },
            isVisible: () => { var _a; return ((_a = notebookTracker.activeCell) === null || _a === void 0 ? void 0 : _a.model.type) === 'code'; }
        });
        app.commands.addCommand(CommandIds.executeAndPrint, {
            icon: _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.markdownIcon,
            caption: 'Print output to console',
            execute: async () => {
                var _a;
                const activeCell = notebookTracker.currentWidget;
                if (activeCell) {
                    // This is code how we can execute a cell!
                    //const sessionContext = activeCell.sessionContext;
                    // Execute the active cell
                    //await NotebookActions.run(
                    //  notebookTracker.currentWidget!.content,
                    //  sessionContext
                    //);
                    // Print the output of the cell to the console
                    const cellOutput = (_a = activeCell.content.activeCell) === null || _a === void 0 ? void 0 : _a.model.toJSON().outputs;
                    if (Array.isArray(cellOutput)) {
                        const firstOutput = cellOutput[0];
                        console.log('First output:', firstOutput);
                        if (isExecuteResult(firstOutput)) {
                            const data = firstOutput.data['image/png'];
                            console.log('<img src="data:image/png;base64,', data.toString(), '"/>');
                        }
                        else {
                            console.log('No output');
                        }
                    }
                }
                //app.commands.execute('notebook:run-cell');
            },
            isVisible: () => { var _a; return ((_a = notebookTracker.activeCell) === null || _a === void 0 ? void 0 : _a.model.type) === 'code'; }
        });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);


/***/ }),

/***/ "./lib/login.js":
/*!**********************!*\
  !*** ./lib/login.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Login: () => (/* binding */ Login)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _services_login__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./services/login */ "./lib/services/login.js");


const Login = ({ setActiveComponent, token, setToken }) => {
    const [username, setUsername] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [password, setPassword] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const navigateToRegister = () => {
        setActiveComponent('register');
    };
    const navigateToChooseRoom = () => {
        setActiveComponent('choose_room');
    };
    const handleLogin = async (event) => {
        event.preventDefault();
        try {
            const token = await _services_login__WEBPACK_IMPORTED_MODULE_1__["default"].login({
                username,
                password,
            });
            window.localStorage.setItem('loggedPuzzleappUser', JSON.stringify(token));
            setToken(token);
            setUsername('');
            setPassword('');
            navigateToChooseRoom();
        }
        catch (exception) {
            alert('Wrong credentials');
        }
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "login-wrapper" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "title" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h1", null, "Login")),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("form", { className: "login-form", onSubmit: handleLogin },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { className: "login-input", type: "text", placeholder: "Username", value: username, onChange: (e) => setUsername(e.target.value), required: true }),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { className: "login-input", type: "text", placeholder: "Password", value: password, onChange: (e) => setPassword(e.target.value), required: true }),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "login-button", type: "submit" }, "Login"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: "login-p" },
                "Don't have an account? ",
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("a", { className: "login-a", onClick: navigateToRegister }, "Register")))));
};


/***/ }),

/***/ "./lib/mytestcases.js":
/*!****************************!*\
  !*** ./lib/mytestcases.js ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MyTestcases: () => (/* binding */ MyTestcases)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _services_testcases__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./services/testcases */ "./lib/services/testcases.js");
/* harmony import */ var _WrapperComponent__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./WrapperComponent */ "./lib/WrapperComponent.js");



const MyTestcases = ({ setActiveComponent, token, pin_code, setToken }) => {
    const [testcases, setTestcases] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [expandedTestcase, setExpandedTestcase] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [pendingTestcases, setPendingTestcases] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [expandedPendingTestcase, setExpandedPendingTestcase] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const initialTestcases = async () => {
        try {
            const t = await _services_testcases__WEBPACK_IMPORTED_MODULE_1__["default"].getMyTestcases(pin_code);
            setTestcases(t);
            const p = await _services_testcases__WEBPACK_IMPORTED_MODULE_1__["default"].getMyPending(pin_code);
            setPendingTestcases(p);
        }
        catch (exception) {
            alert(exception);
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (!token) {
            setActiveComponent('login');
        }
        else if (token.token) {
            initialTestcases();
        }
    }, [pin_code]);
    const toggleVisibility = (testcaseId) => {
        setExpandedTestcase(expandedTestcase === testcaseId ? null : testcaseId);
    };
    const ptoggleVisibility = (testcaseId) => {
        setExpandedPendingTestcase(expandedPendingTestcase === testcaseId ? null : testcaseId);
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_WrapperComponent__WEBPACK_IMPORTED_MODULE_2__["default"], { setActiveComponent: setActiveComponent, setToken: setToken, token: token, pin_code: pin_code },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "title" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h1", null, "My Testcases (pending)")),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "mytestcases-scrollbox1" }, pendingTestcases.map((ptestcase, index) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { key: index, className: "testcase-container" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "testcase-header", onClick: () => ptoggleVisibility(ptestcase.id) },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "toggle-button" }, expandedPendingTestcase === ptestcase.id ? '−' : '+'),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h2", { className: "testcase-description" }, ptestcase.description)),
            expandedPendingTestcase === ptestcase.id && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "testcase-details" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "tile-grid" }, ptestcase.input.map((input, iIndex) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { key: iIndex, className: `tile ${ptestcase.expected_output[iIndex] === ptestcase.reference_output[iIndex] ? 'match' : 'mismatch'}` },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("img", { src: input, alt: "", className: "tile-img" }),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: "tile-label" },
                            "Expected: ",
                            ptestcase.expected_output[iIndex] || 'N/A'),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: "tile-label" },
                            "Reference: ",
                            ptestcase.reference_output[iIndex] || 'N/A')))))))))))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "title" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h1", null, "My Testcases")),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "mytestcases-scrollbox2" }, testcases.map((testcase, index) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { key: index, className: "testcase-container" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "testcase-header", onClick: () => toggleVisibility(testcase.id) },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "toggle-button" }, expandedTestcase === testcase.id ? '−' : '+'),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h2", { className: "testcase-description" }, testcase.description)),
            expandedTestcase === testcase.id && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "testcase-details" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "tile-grid" }, testcase.input.map((input, iIndex) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { key: iIndex, className: "tile" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("img", { src: input, alt: "", className: "tile-img" }),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: "tile-label" },
                            "Expected: ",
                            testcase.expected_output[iIndex] || 'N/A'),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: "tile-label" }, "Actual: -"))))))))))))));
};


/***/ }),

/***/ "./lib/navbar.js":
/*!***********************!*\
  !*** ./lib/navbar.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _services_rooms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./services/rooms */ "./lib/services/rooms.js");


const Navbar = ({ setActiveComponent, setToken, token, pin_code }) => {
    const [room, setRoom] = react__WEBPACK_IMPORTED_MODULE_0___default().useState(null);
    react__WEBPACK_IMPORTED_MODULE_0___default().useEffect(() => {
        if (!token) {
            setActiveComponent('login');
        }
        else if (token.token && pin_code) {
            initialRoom();
        }
    }, [pin_code, token]);
    const initialRoom = async () => {
        try {
            const r = await _services_rooms__WEBPACK_IMPORTED_MODULE_1__["default"].getRoom(pin_code);
            setRoom(r);
        }
        catch (exception) {
            alert(exception);
        }
    };
    const handleLogout = () => {
        window.localStorage.removeItem('loggedPuzzleappUser');
        setToken(null);
        setActiveComponent('login');
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "room-navbar" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "left-items" }, pin_code && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("a", { onClick: () => setActiveComponent('room') }, "Task"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "room-dropdown" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "room-dropbtn" }, "Testcases \u25BC"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "room-dropdown-content" },
                    (token === null || token === void 0 ? void 0 : token.id) === (room === null || room === void 0 ? void 0 : room.instructor_id) && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("a", { onClick: () => setActiveComponent('pending_testcases') }, "Pending Testcases")),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("a", { onClick: () => setActiveComponent('all_testcases') }, "All Testcases"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("a", { onClick: () => setActiveComponent('create_testcases') }, "Create Testcases"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("a", { onClick: () => setActiveComponent('my_testcases') }, "My Testcases")))))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "right-items" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "room-dropdown" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "room-dropbtn" }, "Profile \u25BC"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "room-dropdown-content" },
                    pin_code && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("a", { onClick: () => setActiveComponent('choose_room') }, "Change Room"),
                        (token === null || token === void 0 ? void 0 : token.id) === (room === null || room === void 0 ? void 0 : room.instructor_id) && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("a", { onClick: () => {
                                    if (window.confirm('Are you sure you want to delete the room?')) {
                                        _services_rooms__WEBPACK_IMPORTED_MODULE_1__["default"].deleteRoom(pin_code);
                                        setActiveComponent('choose_room');
                                    }
                                } }, "Delete Room"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("a", { onClick: () => {
                                    setActiveComponent('update_room');
                                } }, "Update Room"))))),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("a", { onClick: () => setActiveComponent('update_profile') }, "Update Profile"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("a", { onClick: handleLogout }, "Logout"))))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Navbar);


/***/ }),

/***/ "./lib/newroom.js":
/*!************************!*\
  !*** ./lib/newroom.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   NewRoom: () => (/* binding */ NewRoom)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _services_rooms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./services/rooms */ "./lib/services/rooms.js");
/* harmony import */ var _WrapperComponent__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./WrapperComponent */ "./lib/WrapperComponent.js");



const NewRoom = ({ setActiveComponent, token, setRoomPin, setToken }) => {
    const [roomName, setRoomName] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [description, setDescription] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [notebookFile, setNotebookFile] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (!token) {
            setActiveComponent('login');
        }
        else if (token.token) {
            _services_rooms__WEBPACK_IMPORTED_MODULE_1__["default"].setToken(token.token);
        }
    }, [token, setActiveComponent]);
    const createRoom = async (event) => {
        event.preventDefault();
        try {
            const formData = new FormData();
            formData.append('room_name', roomName);
            formData.append('task_description', description);
            if (notebookFile) {
                formData.append('notebook', notebookFile);
            }
            let newRoom = await _services_rooms__WEBPACK_IMPORTED_MODULE_1__["default"].create(formData);
            setRoomName('');
            setDescription('');
            setNotebookFile(null);
            setRoomPin(newRoom.pin_code);
            setActiveComponent('room');
        }
        catch (exception) {
            alert(exception);
        }
    };
    const handleCancel = () => {
        setActiveComponent('choose_room');
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_WrapperComponent__WEBPACK_IMPORTED_MODULE_2__["default"], { setActiveComponent: setActiveComponent, setToken: setToken, token: token },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "title" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h1", null, "New Room")),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("form", { className: "login-form2", onSubmit: createRoom },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { className: "login-input", type: "text", placeholder: "Room name", value: roomName, onChange: (e) => setRoomName(e.target.value), required: true }),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("textarea", { className: "new-room-textarea", placeholder: "description", value: description, onChange: (e) => setDescription(e.target.value), required: true }),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { id: "fileUpload", className: "new-room-hidden", type: "file", accept: ".ipynb", onChange: (e) => setNotebookFile(e.target.files ? e.target.files[0] : null) }),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "new-room-button", htmlFor: "fileUpload" }, notebookFile ? `Selected: ${notebookFile.name}` : 'Upload File'),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "login-button", type: "submit" }, "Create"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "room-cancel-button", type: "button", onClick: handleCancel }, "Cancel"))));
};


/***/ }),

/***/ "./lib/pendingtestcases.js":
/*!*********************************!*\
  !*** ./lib/pendingtestcases.js ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PendingTestcases: () => (/* binding */ PendingTestcases)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _services_testcases__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./services/testcases */ "./lib/services/testcases.js");
/* harmony import */ var _WrapperComponent__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./WrapperComponent */ "./lib/WrapperComponent.js");
/* harmony import */ var _autosizeinput__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./autosizeinput */ "./lib/autosizeinput.js");




const PendingTestcases = ({ setActiveComponent, token, pin_code, setToken }) => {
    const [pendingTestcases, setPendingTestcases] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [expandedPendingTestcase, setExpandedPendingTestcase] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const initialTestcases = async () => {
        try {
            const p = await _services_testcases__WEBPACK_IMPORTED_MODULE_1__["default"].getAllPending(pin_code);
            setPendingTestcases(p);
        }
        catch (exception) {
            alert(exception);
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (!token) {
            setActiveComponent('login');
        }
        else if (token.token) {
            initialTestcases();
        }
    }, [pin_code]);
    const ptoggleVisibility = (testcaseId) => {
        setExpandedPendingTestcase(expandedPendingTestcase === testcaseId ? null : testcaseId);
    };
    const handleEditExpectedOutput = (testcaseId, index, newValue) => {
        setPendingTestcases(prevTestcases => prevTestcases.map(testcase => testcase.id === testcaseId
            ? { ...testcase, expected_output: testcase.expected_output.map((output, i) => i === index ? newValue : output) }
            : testcase));
    };
    const handleDeletePair = (testcaseId, index) => {
        setPendingTestcases(prevTestcases => prevTestcases.map(testcase => testcase.id === testcaseId
            ? {
                ...testcase,
                input: testcase.input.filter((_, i) => i !== index),
                expected_output: testcase.expected_output.filter((_, i) => i !== index),
                reference_output: testcase.reference_output.filter((_, i) => i !== index)
            }
            : testcase));
    };
    const handleApprove = async (testcaseId) => {
        try {
            const testcaseToApprove = pendingTestcases.find(tc => tc.id === testcaseId);
            if (testcaseToApprove) {
                await _services_testcases__WEBPACK_IMPORTED_MODULE_1__["default"].approvePending(pin_code, testcaseId, testcaseToApprove);
                setPendingTestcases(prevTestcases => prevTestcases.filter(tc => tc.id !== testcaseId));
            }
        }
        catch (error) {
            console.error("Error approving testcase:", error);
            alert("Failed to approve testcase");
        }
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_WrapperComponent__WEBPACK_IMPORTED_MODULE_2__["default"], { setActiveComponent: setActiveComponent, setToken: setToken, token: token, pin_code: pin_code },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "title" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h1", null, "Testcases (pending)")),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "mytestcases-scrollbox1" }, pendingTestcases.map((ptestcase, index) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { key: index, className: "testcase-container" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "testcase-header", onClick: () => ptoggleVisibility(ptestcase.id) },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "toggle-button" }, expandedPendingTestcase === ptestcase.id ? '−' : '+'),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h2", { className: "testcase-description" }, ptestcase.description),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "approve-button", onClick: (e) => {
                        e.stopPropagation();
                        handleApprove(ptestcase.id);
                    } }, "\u2713")),
            expandedPendingTestcase === ptestcase.id && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "testcase-details" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "tile-grid" }, ptestcase.input.map((input, iIndex) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { key: iIndex, className: `tile ${ptestcase.expected_output[iIndex] === ptestcase.reference_output[iIndex] ? 'match' : 'mismatch'}` },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "image-container" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("img", { src: input, alt: "", className: "tile-img" }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "delete-button", onClick: (e) => {
                                e.stopPropagation();
                                handleDeletePair(ptestcase.id, iIndex);
                            } }, "\u2715")),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: "tile-label" },
                            "Expected:",
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_autosizeinput__WEBPACK_IMPORTED_MODULE_3__["default"], { value: ptestcase.expected_output[iIndex], onChange: (e) => handleEditExpectedOutput(ptestcase.id, iIndex, e.target.value) })),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: "tile-label" },
                            "Reference: ",
                            ptestcase.reference_output[iIndex]))))))))))))));
};


/***/ }),

/***/ "./lib/rectangulardrawing.js":
/*!***********************************!*\
  !*** ./lib/rectangulardrawing.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_konva__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-konva */ "webpack/sharing/consume/default/react-konva/react-konva");
/* harmony import */ var react_konva__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_konva__WEBPACK_IMPORTED_MODULE_1__);


function Canvas({ handleUpload }) {
    const [tool, setTool] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('brush');
    const [lines, setLines] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [brushWidth, setBrushWidth] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(21);
    const isDrawing = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(false);
    const stageRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const [label, setLabel] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const handleMouseDown = e => {
        isDrawing.current = true;
        const pos = e.target.getStage().getPointerPosition();
        setLines([...lines, { tool, points: [pos.x, pos.y], brushWidth }]);
    };
    const handleMouseMove = e => {
        if (!isDrawing.current) {
            return;
        }
        const stage = e.target.getStage();
        const point = stage.getPointerPosition();
        const lastLine = lines[lines.length - 1];
        lastLine.points = lastLine.points.concat([point.x, point.y]);
        lines.splice(lines.length - 1, 1, lastLine);
        setLines(lines.concat());
    };
    const handleMouseUp = () => {
        isDrawing.current = false;
    };
    const handleClear = () => {
        setLines([]);
    };
    const handleExport = () => {
        const uri = stageRef.current.toDataURL();
        console.log(uri);
        handleUpload(uri, label);
        handleClear();
        setLabel('');
        // we also can save uri as file
        // but in the demo on Konva website it will not work
        // because of iframe restrictions
        // but feel free to use it in your apps:
        // downloadURI(uri, 'stage.png');
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { display: 'flex', flexDirection: 'column', alignItems: 'center' } },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { display: 'flex', justifyContent: 'space-between', width: '250px' } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { onClick: handleClear }, "Clear"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("select", { value: tool, onChange: e => {
                    setTool(e.target.value);
                } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "brush" }, "Brush"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "eraser" }, "Eraser")),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { style: { width: '70px' }, type: "range", id: "brushWidth", min: "21", max: "40", value: brushWidth, onChange: e => {
                        setBrushWidth(parseInt(e.target.value, 10));
                    } }))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { width: '250px', height: '250px', border: '1px solid black' } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_konva__WEBPACK_IMPORTED_MODULE_1__.Stage, { width: 250, height: 250, onMouseDown: handleMouseDown, onMousemove: handleMouseMove, onMouseup: handleMouseUp, onTouchstart: handleMouseDown, onTouchmove: handleMouseMove, onTouchend: handleMouseUp, ref: stageRef },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_konva__WEBPACK_IMPORTED_MODULE_1__.Layer, null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_konva__WEBPACK_IMPORTED_MODULE_1__.Rect, { width: 250, height: 250, fill: "white" }),
                    lines.map((line, i) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_konva__WEBPACK_IMPORTED_MODULE_1__.Line, { key: i, points: line.points, stroke: "#000", strokeWidth: line.brushWidth, tension: 0.5, lineCap: "round", lineJoin: "round", globalCompositeOperation: line.tool === 'eraser' ? 'destination-out' : 'source-over' })))))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { display: 'flex', justifyContent: 'space-around', width: '250px' } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", null,
                "Label",
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { style: { width: '20px' }, type: "text", value: label, onChange: (e) => setLabel(e.target.value) })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { onClick: handleExport }, "Add"))));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Canvas);


/***/ }),

/***/ "./lib/register.js":
/*!*************************!*\
  !*** ./lib/register.js ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Register: () => (/* binding */ Register)
/* harmony export */ });
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./config */ "./lib/config.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! axios */ "webpack/sharing/consume/default/axios/axios");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);



const Register = ({ setActiveComponent }) => {
    const [username, setUsername] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [password, setPassword] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [confirmPassword, setConfirmPassword] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const navigateToLogin = () => {
        setActiveComponent('login');
    };
    const handleSubmit = async (e) => {
        e.preventDefault();
        if (password !== confirmPassword) {
            alert('Passwords do not match');
            return;
        }
        try {
            const response = await axios__WEBPACK_IMPORTED_MODULE_1___default().post(`${_config__WEBPACK_IMPORTED_MODULE_2__.config.BACKEND_URL}/users/register`, {
                username,
                password,
            });
            if (response.status === 201) {
                alert('Registration successful');
                navigateToLogin();
            }
            else {
                alert('Registration failed');
            }
        }
        catch (error) {
            console.error('Error:', error);
            if (axios__WEBPACK_IMPORTED_MODULE_1___default().isAxiosError(error)) {
                if (error.response && error.response.data && typeof error.response.data === 'object') {
                    const errorData = error.response.data;
                    alert(errorData.error);
                }
                else {
                    alert('An error occurred during registration');
                }
            }
            else {
                alert('An unknown error occurred');
            }
        }
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "login-wrapper" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "title" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h1", null, "Register")),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("form", { className: "login-form", onSubmit: handleSubmit },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { className: "login-input", type: "text", placeholder: "Username", value: username, onChange: (e) => setUsername(e.target.value), required: true }),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { className: "login-input", type: "text", placeholder: "Password", value: password, onChange: (e) => setPassword(e.target.value), required: true }),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { className: "login-input", type: "text", placeholder: "Confirm Password", value: confirmPassword, onChange: (e) => setConfirmPassword(e.target.value), required: true }),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "login-button", type: "submit" }, "Register"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: "login-p" },
                "Already have an account? ",
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("a", { className: "login-a", onClick: navigateToLogin }, "Log in")))));
};


/***/ }),

/***/ "./lib/room.js":
/*!*********************!*\
  !*** ./lib/room.js ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Room: () => (/* binding */ Room)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _services_rooms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./services/rooms */ "./lib/services/rooms.js");
/* harmony import */ var _WrapperComponent__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./WrapperComponent */ "./lib/WrapperComponent.js");
/* harmony import */ var _InstructorUpload__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./InstructorUpload */ "./lib/InstructorUpload.js");
/* harmony import */ var _StudentUpload__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./StudentUpload */ "./lib/StudentUpload.js");





const Room = ({ setActiveComponent, token, pin_code, setToken, notebooktracker }) => {
    var _a, _b;
    const [room, setRoom] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const initialRoom = async () => {
        try {
            await _services_rooms__WEBPACK_IMPORTED_MODULE_1__["default"].join(pin_code);
            const r = await _services_rooms__WEBPACK_IMPORTED_MODULE_1__["default"].getRoom(pin_code);
            setRoom(r);
        }
        catch (exception) {
            alert(exception);
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (!token) {
            setActiveComponent('login');
        }
        else if (token.token) {
            _services_rooms__WEBPACK_IMPORTED_MODULE_1__["default"].setToken(token.token);
            initialRoom();
        }
    }, [pin_code]);
    const handleDownload = async () => {
        if (!room)
            return;
        // try put in room service
        try {
            const response = await _services_rooms__WEBPACK_IMPORTED_MODULE_1__["default"].getNotebook(room.pin_code);
            /*https://stackoverflow.com/questions/3665115/how-to-create-a-file-in-memory-for-user-to-download-but-not-through-server/18197341#18197341*/
            if (response.status !== 200) {
                throw new Error('Failed to download notebook');
            }
            const blob = new Blob([response.data], { type: 'application/octet-stream' });
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'notebook.ipynb';
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);
        }
        catch (error) {
            alert(error);
        }
    };
    console.log(room);
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_WrapperComponent__WEBPACK_IMPORTED_MODULE_2__["default"], { setActiveComponent: setActiveComponent, setToken: setToken, token: token, pin_code: pin_code },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "room-box" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h2", null, room === null || room === void 0 ? void 0 : room.room_name),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null, room === null || room === void 0 ? void 0 : room.task.description)),
        ((_a = room === null || room === void 0 ? void 0 : room.task) === null || _a === void 0 ? void 0 : _a.hasnotebook) && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: 'new-room-button', onClick: handleDownload }, "Download Notebook")),
        !((_b = room === null || room === void 0 ? void 0 : room.task) === null || _b === void 0 ? void 0 : _b.hasnotebook) && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null, "No notebook available")),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_InstructorUpload__WEBPACK_IMPORTED_MODULE_3__["default"], { isVisible: (token === null || token === void 0 ? void 0 : token.id) === (room === null || room === void 0 ? void 0 : room.instructor_id), notebooktracker: notebooktracker, pin_code: pin_code, token: token }),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_StudentUpload__WEBPACK_IMPORTED_MODULE_4__["default"], { isVisible: (token === null || token === void 0 ? void 0 : token.id) !== (room === null || room === void 0 ? void 0 : room.instructor_id), notebooktracker: notebooktracker, pin_code: pin_code, token: token })));
};


/***/ }),

/***/ "./lib/services/login.js":
/*!*******************************!*\
  !*** ./lib/services/login.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../config */ "./lib/config.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! axios */ "webpack/sharing/consume/default/axios/axios");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);


const baseUrl = `${_config__WEBPACK_IMPORTED_MODULE_1__.config.BACKEND_URL}/users/login`;
const login = async (credentials) => {
    const response = await axios__WEBPACK_IMPORTED_MODULE_0___default().post(baseUrl, credentials);
    return response.data;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({ login });


/***/ }),

/***/ "./lib/services/rooms.js":
/*!*******************************!*\
  !*** ./lib/services/rooms.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../config */ "./lib/config.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! axios */ "webpack/sharing/consume/default/axios/axios");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var yjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! yjs */ "webpack/sharing/consume/default/yjs");
/* harmony import */ var yjs__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(yjs__WEBPACK_IMPORTED_MODULE_1__);



const baseUrl = `${_config__WEBPACK_IMPORTED_MODULE_2__.config.BACKEND_URL}/rooms`;
let token = null;
const setToken = newToken => {
    token = `Bearer ${newToken}`;
};
const getAll = async () => {
    const config = { headers: { Authorization: token } };
    const request = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(baseUrl, config);
    return request.data;
};
const getRoom = async (pin_code) => {
    const config = { headers: { Authorization: token } };
    const request = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${baseUrl}/${pin_code}`, config);
    return request.data;
};
const create = async (newObject) => {
    const config = { headers: { Authorization: token, 'Content-Type': 'multipart/form-data' } };
    const request = await axios__WEBPACK_IMPORTED_MODULE_0___default().post(baseUrl, newObject, config);
    return request.data;
};
const join = async (pin_code) => {
    const config = { headers: { Authorization: token } };
    const request = await axios__WEBPACK_IMPORTED_MODULE_0___default().put(`${baseUrl}/${pin_code}/join`, {}, config);
    return request.data;
};
const myrooms = async () => {
    const config = { headers: { Authorization: token } };
    const request = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${baseUrl}/myrooms`, config);
    return request.data;
};
const getNotebook = async (pin_code) => {
    const config = { headers: { Authorization: token, 'Content-Type': 'application/octet-stream' }, responseType: 'blob' };
    const request = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${baseUrl}/${pin_code}/notebook`, config);
    return request;
};
const deleteRoom = async (pin_code) => {
    const config = { headers: { Authorization: token } };
    const request = await axios__WEBPACK_IMPORTED_MODULE_0___default()["delete"](`${baseUrl}/${pin_code}`, config);
    return request.data;
};
const update = async (pin_code, updatedObject) => {
    const config = {
        headers: {
            Authorization: token,
            'Content-Type': 'multipart/form-data'
        }
    };
    const request = await axios__WEBPACK_IMPORTED_MODULE_0___default().put(`${baseUrl}/${pin_code}`, updatedObject, config);
    return request.data;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    getAll, create, join, myrooms, setToken, getRoom, getNotebook, deleteRoom, update
});


/***/ }),

/***/ "./lib/services/submissions.js":
/*!*************************************!*\
  !*** ./lib/services/submissions.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../config */ "./lib/config.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! axios */ "webpack/sharing/consume/default/axios/axios");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var yjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! yjs */ "webpack/sharing/consume/default/yjs");
/* harmony import */ var yjs__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(yjs__WEBPACK_IMPORTED_MODULE_1__);



const baseUrl = `${_config__WEBPACK_IMPORTED_MODULE_2__.config.BACKEND_URL}/submissions`;
let token = null;
const setToken = newToken => {
    token = `Bearer ${newToken}`;
};
const submit = async (pin_code, func) => {
    const config = { headers: { Authorization: token } };
    const request = await axios__WEBPACK_IMPORTED_MODULE_0___default().post(`${baseUrl}/${pin_code}`, { func: func }, config);
    return request.data;
};
const getMySubmission = async (pin_code) => {
    const config = { headers: { Authorization: token } };
    const request = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${baseUrl}/${pin_code}/mysubmissions/`, config);
    return request.data;
};
const updateSubmission = async (pin_code) => {
    console.log(token);
    const config = { headers: { Authorization: token } };
    const request = await axios__WEBPACK_IMPORTED_MODULE_0___default().post(`${baseUrl}/${pin_code}/update/`, {}, config);
    return request.data;
};
// update submit later
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({ setToken, submit, getMySubmission, updateSubmission });


/***/ }),

/***/ "./lib/services/testcases.js":
/*!***********************************!*\
  !*** ./lib/services/testcases.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../config */ "./lib/config.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! axios */ "webpack/sharing/consume/default/axios/axios");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var yjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! yjs */ "webpack/sharing/consume/default/yjs");
/* harmony import */ var yjs__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(yjs__WEBPACK_IMPORTED_MODULE_1__);



const baseUrl = `${_config__WEBPACK_IMPORTED_MODULE_2__.config.BACKEND_URL}/testcases`;
let token = null;
const setToken = newToken => {
    token = `Bearer ${newToken}`;
};
const create = async (pin_code, input, expected_output, description) => {
    const config = { headers: { Authorization: token } };
    const request = await axios__WEBPACK_IMPORTED_MODULE_0___default().post(`${baseUrl}/${pin_code}`, { input, expected_output, description }, config);
    return request.data;
};
const getAll = async (pin_code) => {
    const config = { headers: { Authorization: token } };
    const request = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${baseUrl}/${pin_code}`, config);
    return request.data;
};
const getMyTestcases = async (pin_code) => {
    const config = { headers: { Authorization: token } };
    const request = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${baseUrl}/${pin_code}/mytestcases/`, config);
    return request.data;
};
const getAllPending = async (pin_code) => {
    const config = { headers: { Authorization: token } };
    const request = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${baseUrl}/${pin_code}/pendingtestcases/`, config);
    return request.data;
};
const getMyPending = async (pin_code) => {
    const config = { headers: { Authorization: token } };
    const request = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${baseUrl}/${pin_code}/mypendingtestcases/`, config);
    return request.data;
};
const approvePending = async (pin_code, testcase_id, modifiedTestcase) => {
    const config = { headers: { Authorization: token } };
    const request = await axios__WEBPACK_IMPORTED_MODULE_0___default().put(`${baseUrl}/${pin_code}/approvependingtestcases/${testcase_id}`, { modifiedTestcase }, config);
    return request.data;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    setToken, create, getAll, getMyTestcases, getAllPending, getMyPending, approvePending
});


/***/ }),

/***/ "./lib/shoutstatusbar.js":
/*!*******************************!*\
  !*** ./lib/shoutstatusbar.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ShoutStatusBarSummary: () => (/* binding */ ShoutStatusBarSummary)
/* harmony export */ });
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_0__);

class ShoutStatusBarSummary extends _lumino_widgets__WEBPACK_IMPORTED_MODULE_0__.Widget {
    constructor() {
        super();
        // Display the last shout time in the status bar
        this._statusBarSummary = document.createElement('p');
        this._statusBarSummary.classList.add('jp-shout-summary');
        this._statusBarSummary.innerText = 'Last Shout: (None)';
        this.node.appendChild(this._statusBarSummary);
    }
    /**
     * Set the widget text content
     *
     * @param summary The text to display
     */
    setSummary(summary) {
        this._statusBarSummary.innerText = summary;
    }
}


/***/ }),

/***/ "./lib/sidebar.js":
/*!************************!*\
  !*** ./lib/sidebar.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Sidebar: () => (/* binding */ Sidebar)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _login__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./login */ "./lib/login.js");
/* harmony import */ var _register__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./register */ "./lib/register.js");
/* harmony import */ var _chooseroom__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./chooseroom */ "./lib/chooseroom.js");
/* harmony import */ var _room__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./room */ "./lib/room.js");
/* harmony import */ var _newroom__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./newroom */ "./lib/newroom.js");
/* harmony import */ var _updateroom__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./updateroom */ "./lib/updateroom.js");
/* harmony import */ var _mytestcases__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./mytestcases */ "./lib/mytestcases.js");
/* harmony import */ var _pendingtestcases__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./pendingtestcases */ "./lib/pendingtestcases.js");
/* harmony import */ var _alltestcases__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./alltestcases */ "./lib/alltestcases.js");
/* harmony import */ var _createtestcases__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./createtestcases */ "./lib/createtestcases.js");
/* harmony import */ var _services_rooms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./services/rooms */ "./lib/services/rooms.js");
/* harmony import */ var _services_testcases__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./services/testcases */ "./lib/services/testcases.js");
/* harmony import */ var _services_submissions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./services/submissions */ "./lib/services/submissions.js");














const Sidebar = ({ _lastShoutMessage, _messageShouted, _notebookTracker }) => {
    const [activeComponent, setActiveComponent] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('register');
    const [token, setToken] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [roomPin, setRoomPin] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const setAllTokens = (token) => {
        setToken(token);
        _services_rooms__WEBPACK_IMPORTED_MODULE_1__["default"].setToken(token === null || token === void 0 ? void 0 : token.token);
        _services_testcases__WEBPACK_IMPORTED_MODULE_2__["default"].setToken(token === null || token === void 0 ? void 0 : token.token);
        _services_submissions__WEBPACK_IMPORTED_MODULE_3__["default"].setToken(token === null || token === void 0 ? void 0 : token.token);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        const loggedUserJSON = window.localStorage.getItem('loggedPuzzleappUser');
        if (loggedUserJSON) {
            const user = JSON.parse(loggedUserJSON);
            setAllTokens(user);
        }
    }, []);
    const renderComponent = () => {
        switch (activeComponent) {
            case 'login':
                return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_login__WEBPACK_IMPORTED_MODULE_4__.Login, { setActiveComponent: setActiveComponent, token: token, setToken: setAllTokens });
            case 'register':
                return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_register__WEBPACK_IMPORTED_MODULE_5__.Register, { setActiveComponent: setActiveComponent });
            case 'choose_room':
                return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_chooseroom__WEBPACK_IMPORTED_MODULE_6__.ChooseRoom, { token: token, setActiveComponent: setActiveComponent, setRoomPin: setRoomPin, setToken: setAllTokens });
            case 'room':
                return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_room__WEBPACK_IMPORTED_MODULE_7__.Room, { token: token, setActiveComponent: setActiveComponent, pin_code: roomPin, setToken: setAllTokens, notebooktracker: _notebookTracker });
            case 'my_testcases':
                return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mytestcases__WEBPACK_IMPORTED_MODULE_8__.MyTestcases, { token: token, setActiveComponent: setActiveComponent, pin_code: roomPin, setToken: setAllTokens });
            case 'all_testcases':
                return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_alltestcases__WEBPACK_IMPORTED_MODULE_9__.AllTestcases, { token: token, setActiveComponent: setActiveComponent, pin_code: roomPin, setToken: setAllTokens });
            case 'create_testcases':
                return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_createtestcases__WEBPACK_IMPORTED_MODULE_10__.CreateTestcases, { token: token, setActiveComponent: setActiveComponent, pin_code: roomPin, setToken: setAllTokens });
            case 'pending_testcases':
                return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_pendingtestcases__WEBPACK_IMPORTED_MODULE_11__.PendingTestcases, { token: token, setActiveComponent: setActiveComponent, pin_code: roomPin, setToken: setAllTokens });
            case 'newroom':
                return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_newroom__WEBPACK_IMPORTED_MODULE_12__.NewRoom, { token: token, setActiveComponent: setActiveComponent, setRoomPin: setRoomPin, setToken: setAllTokens });
            case 'update_room':
                return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_updateroom__WEBPACK_IMPORTED_MODULE_13__.UpdateRoom, { token: token, setActiveComponent: setActiveComponent, pin_code: roomPin, setToken: setAllTokens });
            default:
                return null;
        }
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null, renderComponent()));
};


/***/ }),

/***/ "./lib/sidebarwrapper.js":
/*!*******************************!*\
  !*** ./lib/sidebarwrapper.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SideBarWrapperWidget: () => (/* binding */ SideBarWrapperWidget)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @lumino/signaling */ "webpack/sharing/consume/default/@lumino/signaling");
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_lumino_signaling__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _sidebar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./sidebar */ "./lib/sidebar.js");



// Import the ShoutComponent

// ... (other component imports)
class SideBarWrapperWidget extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.ReactWidget {
    constructor(noteBookTracker) {
        super();
        this._lastShoutMessage = '';
        this._messageShouted = new _lumino_signaling__WEBPACK_IMPORTED_MODULE_2__.Signal(this);
        this.addClass('jp-ReactWidget');
        this._notebookTracker = noteBookTracker;
    }
    get lastShoutMessage() {
        return this._lastShoutMessage;
    }
    get messageShouted() {
        return this._messageShouted;
    }
    render() {
        return (react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_sidebar__WEBPACK_IMPORTED_MODULE_3__.Sidebar, { _lastShoutMessage: this._lastShoutMessage, _messageShouted: this._messageShouted, _notebookTracker: this._notebookTracker }));
    }
}


/***/ }),

/***/ "./lib/updateroom.js":
/*!***************************!*\
  !*** ./lib/updateroom.js ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   UpdateRoom: () => (/* binding */ UpdateRoom)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _services_rooms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./services/rooms */ "./lib/services/rooms.js");
/* harmony import */ var _WrapperComponent__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./WrapperComponent */ "./lib/WrapperComponent.js");



const UpdateRoom = ({ setActiveComponent, token, pin_code, setToken }) => {
    const [roomName, setRoomName] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [description, setDescription] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [notebookFile, setNotebookFile] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (!token) {
            setActiveComponent('login');
        }
        else if (token.token) {
            _services_rooms__WEBPACK_IMPORTED_MODULE_1__["default"].setToken(token.token);
        }
    }, [token, setActiveComponent]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        const fetchRoom = async () => {
            try {
                const room = await _services_rooms__WEBPACK_IMPORTED_MODULE_1__["default"].getRoom(pin_code);
                setRoomName(room.room_name);
                setDescription(room.task.description);
                if (room.task.hasnotebook) {
                    const notebookResponse = await _services_rooms__WEBPACK_IMPORTED_MODULE_1__["default"].getNotebook(pin_code);
                    if (notebookResponse.data) {
                        const blob = new Blob([notebookResponse.data], { type: 'application/x-ipynb+json' });
                        const file = new File([blob], "notebook.ipynb", { type: "application/x-ipynb+json" });
                        setNotebookFile(file);
                    }
                }
            }
            catch (exception) {
                alert(exception);
            }
        };
        fetchRoom();
    }, [pin_code]);
    const updateRoom = async (event) => {
        event.preventDefault();
        try {
            const formData = new FormData();
            formData.append('room_name', roomName);
            formData.append('task_description', description);
            if (notebookFile) {
                formData.append('notebook', notebookFile);
            }
            await _services_rooms__WEBPACK_IMPORTED_MODULE_1__["default"].update(pin_code, formData);
            setNotebookFile(null);
            setActiveComponent('room');
        }
        catch (exception) {
            alert(exception);
        }
    };
    const handleCancel = () => {
        setActiveComponent('room');
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_WrapperComponent__WEBPACK_IMPORTED_MODULE_2__["default"], { setActiveComponent: setActiveComponent, setToken: setToken, token: token, pin_code: pin_code },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "title" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h1", null, "Update Room")),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("form", { className: "login-form2", onSubmit: updateRoom },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { className: "login-input", type: "text", placeholder: "Room name", value: roomName, onChange: (e) => setRoomName(e.target.value), required: true }),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("textarea", { className: "new-room-textarea", placeholder: "description", value: description, onChange: (e) => setDescription(e.target.value), required: true }),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { id: "fileUpload", className: "new-room-hidden", type: "file", accept: ".ipynb", onChange: (e) => setNotebookFile(e.target.files ? e.target.files[0] : null) }),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "new-room-button", htmlFor: "fileUpload" }, notebookFile ? `Selected: ${notebookFile.name}` : 'Upload New Notebook'),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "login-button", type: "submit" }, "Update"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "room-cancel-button", type: "button", onClick: handleCancel }, "Cancel"))));
};


/***/ })

}]);
//# sourceMappingURL=lib_index_js.5ebe848e7fdfa074159b.js.map